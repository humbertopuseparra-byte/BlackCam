package com.blackcam.app

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.os.Build
import android.os.IBinder
import android.provider.MediaStore
import androidx.camera.core.CameraSelector
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RecordingService : LifecycleService() {
    companion object {
        const val START = "com.blackcam.app.START"
        const val STOP = "com.blackcam.app.STOP"
        const val STATUS = "com.blackcam.app.STATUS"
        @Volatile var isRecording = false
            private set
        private const val CHANNEL = "blackcam_recording"
        private const val NOTIFICATION_ID = 7
    }
    private var recording: Recording? = null
    private var provider: ProcessCameraProvider? = null
    private var starting = false

    override fun onCreate() {
        super.onCreate()
        val channel = NotificationChannel(CHANNEL, "Grabación activa", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        when (intent?.action) {
            START -> if (!isRecording && !starting) {
                if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED ||
                    checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    report("error", "Faltan permisos de cámara o micrófono")
                    stopSelf()
                } else {
                    starting = true
                    try {
                        startForeground(NOTIFICATION_ID, notification())
                        beginCamera(intent.getBooleanExtra("front", false))
                    } catch (e: Exception) { fail(e.message ?: "No se pudo iniciar el servicio") }
                }
            }
            STOP -> {
                if (recording != null) recording?.stop() else { starting = false; stopSelf() }
            }
        }
        return START_NOT_STICKY
    }

    private fun notification(): Notification {
        val stopIntent = Intent(this, RecordingService::class.java).setAction(STOP)
        val pending = PendingIntent.getService(this, 1, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.presence_video_online)
            .setContentTitle("BlackCam · Cámara y micrófono")
            .setContentText("Grabación en curso. Toca Detener para finalizar.")
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "Detener", pending)
            .build()
    }

    private fun beginCamera(front: Boolean) {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                if (!starting) { stopSelf(); return@addListener }
                val cameraProvider = future.get()
                provider = cameraProvider
                val recorder = Recorder.Builder().setQualitySelector(
                    QualitySelector.from(Quality.HD, FallbackStrategy.lowerQualityOrHigherThan(Quality.HD))
                ).build()
                val videoCapture = VideoCapture.withOutput(recorder)
                val selector = if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(this, selector, videoCapture)
                val name = "BlackCam_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
                val values = android.content.ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, name)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/BlackCam")
                }
                val options = MediaStoreOutputOptions.Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
                    .setContentValues(values).build()
                recording = recorder.prepareRecording(this, options).withAudioEnabled()
                    .start(ContextCompat.getMainExecutor(this)) { event ->
                        when (event) {
                            is VideoRecordEvent.Start -> { starting = false; isRecording = true; report("recording") }
                            is VideoRecordEvent.Finalize -> {
                                recording = null; isRecording = false; starting = false
                                if (event.hasError()) report("error", "Error al guardar video: ${event.error}")
                                else report("stopped")
                                stopSelf()
                            }
                        }
                    }
            } catch (e: Exception) { fail(e.message ?: "No se pudo iniciar la cámara") }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun report(state: String, message: String? = null) {
        sendBroadcast(Intent(STATUS).setPackage(packageName).putExtra("state", state).putExtra("message", message))
    }
    private fun fail(message: String) { starting = false; isRecording = false; report("error", message); stopSelf() }
    override fun onDestroy() {
        recording?.stop()
        provider?.unbindAll()
        super.onDestroy()
    }
}
