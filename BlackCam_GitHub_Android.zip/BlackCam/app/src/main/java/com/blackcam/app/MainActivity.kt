package com.blackcam.app

import android.Manifest
import android.app.Activity
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var start: Button
    private lateinit var black: Button
    private lateinit var camera: Switch
    private var blackMode = false
    private var recording = false
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.getStringExtra("state")) {
                "recording" -> { recording = true; refresh() }
                "stopped" -> { recording = false; refresh() }
                "error" -> { recording = false; refresh(); Toast.makeText(this@MainActivity, intent.getStringExtra("message"), Toast.LENGTH_LONG).show() }
            }
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 36, 32, 24); setBackgroundColor(Color.rgb(13,16,23)); gravity = Gravity.CENTER_HORIZONTAL }
        fun addText(value: String, size: Float): TextView = TextView(this).apply { text = value; textSize = size; setTextColor(Color.WHITE); gravity = Gravity.CENTER; root.addView(this, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 28 }) }
        addText("BlackCam", 28f)
        status = addText("Lista para grabar", 17f)
        camera = Switch(this).apply { text = "Usar cámara frontal"; setTextColor(Color.WHITE); textSize = 16f; root.addView(this, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 24 }) }
        start = Button(this).apply { setOnClickListener { if (recording) stopRecording() else ensurePermissions() }; root.addView(this, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 20 }) }
        black = Button(this).apply { setOnClickListener { blackMode = !blackMode; refresh() }; root.addView(this, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 20 }) }
        addText("La grabación activa muestra una notificación de Android. La pantalla negra no apaga físicamente el dispositivo.", 13f)
        setContentView(root)
        refresh()
    }
    private fun refresh() {
        status.text = if (recording) "● Grabación activa" else "Lista para grabar"
        start.text = if (recording) "DETENER GRABACIÓN" else "INICIAR GRABACIÓN"
        black.text = if (blackMode) "MOSTRAR CONTROLES" else "ACTIVAR PANTALLA NEGRA"
        val root = status.parent as LinearLayout
        for (i in 0 until root.childCount) root.getChildAt(i).visibility = if (blackMode) View.INVISIBLE else View.VISIBLE
        black.visibility = View.VISIBLE
        if (blackMode) {
            root.setBackgroundColor(Color.BLACK)
            black.alpha = 0.08f // Control tenue y accesible para salir del modo negro.
        } else {
            root.setBackgroundColor(Color.rgb(13,16,23)); black.alpha = 1f
        }
    }
    private fun ensurePermissions() {
        val permissions = mutableListOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = permissions.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) beginRecording() else requestPermissions(missing.toTypedArray(), 20)
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 20) {
            if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) beginRecording()
            else Toast.makeText(this, "Se requieren permisos de cámara y micrófono", Toast.LENGTH_LONG).show()
        }
    }
    private fun beginRecording() {
        val intent = Intent(this, RecordingService::class.java).setAction(RecordingService.START).putExtra("front", camera.isChecked)
        try { startForegroundService(intent) } catch (e: Exception) { Toast.makeText(this, e.message, Toast.LENGTH_LONG).show() }
    }
    private fun stopRecording() { startService(Intent(this, RecordingService::class.java).setAction(RecordingService.STOP)) }
    override fun onStart() { super.onStart(); val filter = IntentFilter(RecordingService.STATUS); if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, filter, RECEIVER_NOT_EXPORTED) else @Suppress("DEPRECATION") registerReceiver(receiver, filter); recording = RecordingService.isRecording; refresh() }
    override fun onStop() { unregisterReceiver(receiver); super.onStop() }
}
